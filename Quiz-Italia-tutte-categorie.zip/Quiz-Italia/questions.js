const questions = [
  // Categoria: Gioco
  { category: "gioco", question: "Quale azienda ha creato la console PlayStation?", options: ["Sony", "Microsoft", "Nintendo", "Sega"], answer: "Sony" },
  { category: "gioco", question: "In quale gioco da tavolo bisogna conquistare territori con i carri armati?", options: ["Risiko", "Monopoly", "Cluedo", "Scarabeo"], answer: "Risiko" },
  { category: "gioco", question: "Qual è il nome del famoso idraulico italiano dei videogiochi Nintendo?", options: ["Mario", "Luigi", "Wario", "Toad"], answer: "Mario" },
  { category: "gioco", question: "In che anno è uscita la prima console Xbox?", options: ["2001", "1998", "2005", "1995"], answer: "2001" },
  { category: "gioco", question: "Quale gioco da tavolo prevede di comprare e vendere strade e case?", options: ["Monopoly", "Risiko", "Cluedo", "Indovina Chi"], answer: "Monopoly" },
  { category: "gioco", question: "Come si chiama il protagonista della saga videoludica 'The Legend of Zelda'?", options: ["Link", "Zelda", "Ganon", "Sheik"], answer: "Link" },
  { category: "gioco", question: "Quale gioco di carte italiano utilizza i semi coppe, denari, spade e bastoni?", options: ["Scopa", "Poker", "Bridge", "Uno"], answer: "Scopa" },
  { category: "gioco", question: "Qual è il nome del famoso battle royale di Epic Games?", options: ["Fortnite", "PUBG", "Warzone", "Apex Legends"], answer: "Fortnite" },
  { category: "gioco", question: "In quale gioco da tavolo bisogna scoprire l'assassino, l'arma e la stanza?", options: ["Cluedo", "Risiko", "Monopoly", "Taboo"], answer: "Cluedo" },
  { category: "gioco", question: "Quale creatura va catturata nel gioco Pokémon?", options: ["Pokémon", "Digimon", "Mostri", "Draghi"], answer: "Pokémon" },

  // Categoria: Storia
  { category: "storia", question: "Chi fu il primo re d'Italia?", options: ["Vittorio Emanuele II", "Umberto I", "Carlo Alberto", "Garibaldi"], answer: "Vittorio Emanuele II" },
  { category: "storia", question: "In quale anno cadde l'Impero Romano d'Occidente?", options: ["476", "1492", "395", "800"], answer: "476" },
  { category: "storia", question: "Chi guidò la spedizione dei Mille?", options: ["Garibaldi", "Cavour", "Mazzini", "Napoleone"], answer: "Garibaldi" },
  { category: "storia", question: "In quale città fu firmata la resa della Germania nel 1945?", options: ["Berlino", "Mosca", "Parigi", "Varsavia"], answer: "Berlino" },
  { category: "storia", question: "Chi era l’imperatore romano durante l’eruzione del Vesuvio nel 79 d.C.?", options: ["Tito", "Nerone", "Augusto", "Traiano"], answer: "Tito" },

  // Categoria: Geografia
  { category: "geografia", question: "Qual è la capitale della Sardegna?", options: ["Cagliari", "Sassari", "Olbia", "Nuoro"], answer: "Cagliari" },
  { category: "geografia", question: "Qual è il fiume più lungo d’Italia?", options: ["Po", "Arno", "Tevere", "Adige"], answer: "Po" },
  { category: "geografia", question: "Quale catena montuosa divide Italia e Francia?", options: ["Alpi", "Appennini", "Dolomiti", "Pirenei"], answer: "Alpi" },
  { category: "geografia", question: "Qual è la capitale della Sicilia?", options: ["Palermo", "Catania", "Messina", "Trapani"], answer: "Palermo" },
  { category: "geografia", question: "Qual è l’isola più grande del Mediterraneo?", options: ["Sicilia", "Sardegna", "Cipro", "Creta"], answer: "Sicilia" },

  // Categoria: Musica
  { category: "musica", question: "Chi è il compositore della 'Turandot'?", options: ["Puccini", "Verdi", "Rossini", "Bellini"], answer: "Puccini" },
  { category: "musica", question: "Quale strumento suona Miles Davis?", options: ["Tromba", "Pianoforte", "Chitarra", "Violino"], answer: "Tromba" },
  { category: "musica", question: "Chi canta la canzone 'Volare'?", options: ["Domenico Modugno", "Adriano Celentano", "Lucio Dalla", "Mina"], answer: "Domenico Modugno" },
  { category: "musica", question: "Da quale città provengono i Beatles?", options: ["Liverpool", "Londra", "Manchester", "Birmingham"], answer: "Liverpool" },
  { category: "musica", question: "Chi è conosciuto come il 'Re del Pop'?", options: ["Michael Jackson", "Elvis Presley", "Prince", "Freddie Mercury"], answer: "Michael Jackson" },

  // Categoria: Sport
  { category: "sport", question: "Chi ha vinto i Mondiali di calcio nel 2006?", options: ["Italia", "Francia", "Germania", "Brasile"], answer: "Italia" },
  { category: "sport", question: "In quale sport eccelle Valentino Rossi?", options: ["Motociclismo", "Formula 1", "Ciclismo", "Tennis"], answer: "Motociclismo" },
  { category: "sport", question: "Chi ha vinto più titoli di Wimbledon?", options: ["Roger Federer", "Rafael Nadal", "Novak Djokovic", "Pete Sampras"], answer: "Roger Federer" },
  { category: "sport", question: "In quale città si sono tenute le Olimpiadi del 2000?", options: ["Sydney", "Atene", "Pechino", "Londra"], answer: "Sydney" },
  { category: "sport", question: "Quale squadra di calcio ha più Champions League?", options: ["Real Madrid", "Milan", "Liverpool", "Barcellona"], answer: "Real Madrid" },

  // Categoria: Cinema
  { category: "cinema", question: "Chi ha diretto il film 'La dolce vita'?", options: ["Fellini", "Visconti", "De Sica", "Rossellini"], answer: "Fellini" },
  { category: "cinema", question: "Chi interpreta Jack in Titanic?", options: ["Leonardo DiCaprio", "Brad Pitt", "Tom Cruise", "Johnny Depp"], answer: "Leonardo DiCaprio" },
  { category: "cinema", question: "Qual è il film con più Oscar vinti?", options: ["Ben-Hur", "Titanic", "Il Signore degli Anelli - Il ritorno del re", "Tutti"], answer: "Tutti" },
  { category: "cinema", question: "Quale attore interpreta Iron Man?", options: ["Robert Downey Jr.", "Chris Evans", "Mark Ruffalo", "Chris Hemsworth"], answer: "Robert Downey Jr." },
  { category: "cinema", question: "Chi ha diretto 'Inception'?", options: ["Christopher Nolan", "Steven Spielberg", "James Cameron", "Ridley Scott"], answer: "Christopher Nolan" },

  // Categoria: Letteratura
  { category: "letteratura", question: "Chi ha scritto 'La Divina Commedia'?", options: ["Dante Alighieri", "Petrarca", "Boccaccio", "Manzoni"], answer: "Dante Alighieri" },
  { category: "letteratura", question: "Chi ha scritto 'I Promessi Sposi'?", options: ["Alessandro Manzoni", "Gabriele D'Annunzio", "Italo Calvino", "Giovanni Verga"], answer: "Alessandro Manzoni" },
  { category: "letteratura", question: "Chi ha scritto 'Il Gattopardo'?", options: ["Giuseppe Tomasi di Lampedusa", "Pirandello", "Svevo", "Pascoli"], answer: "Giuseppe Tomasi di Lampedusa" },
  { category: "letteratura", question: "Chi è l’autore di '1984'?", options: ["George Orwell", "Aldous Huxley", "J.K. Rowling", "Ernest Hemingway"], answer: "George Orwell" },
  { category: "letteratura", question: "Chi ha scritto 'Ulisse'?", options: ["James Joyce", "T.S. Eliot", "Virginia Woolf", "Kafka"], answer: "James Joyce" },

  // Categoria: Scienza
  { category: "scienza", question: "Chi ha scoperto la penicillina?", options: ["Alexander Fleming", "Louis Pasteur", "Galileo Galilei", "Isaac Newton"], answer: "Alexander Fleming" },
  { category: "scienza", question: "Qual è la formula dell’acqua?", options: ["H2O", "CO2", "O2", "NaCl"], answer: "H2O" },
  { category: "scienza", question: "Chi ha teorizzato la relatività?", options: ["Einstein", "Newton", "Galileo", "Copernico"], answer: "Einstein" },
  { category: "scienza", question: "Qual è il pianeta più vicino al Sole?", options: ["Mercurio", "Venere", "Terra", "Marte"], answer: "Mercurio" },
  { category: "scienza", question: "Chi inventò il telefono?", options: ["Alexander Graham Bell", "Edison", "Marconi", "Tesla"], answer: "Alexander Graham Bell" },

  // Categoria: Arte
  { category: "arte", question: "Chi dipinse la Gioconda?", options: ["Leonardo da Vinci", "Raffaello", "Michelangelo", "Caravaggio"], answer: "Leonardo da Vinci" },
  { category: "arte", question: "In quale città si trova la Cappella Sistina?", options: ["Città del Vaticano", "Roma", "Firenze", "Milano"], answer: "Città del Vaticano" },
  { category: "arte", question: "Chi scolpì il David?", options: ["Michelangelo", "Donatello", "Bernini", "Canova"], answer: "Michelangelo" },
  { category: "arte", question: "Chi dipinse 'La notte stellata'?", options: ["Van Gogh", "Monet", "Cézanne", "Picasso"], answer: "Van Gogh" },
  { category: "arte", question: "Quale movimento artistico è legato a Salvador Dalí?", options: ["Surrealismo", "Cubismo", "Impressionismo", "Barocco"], answer: "Surrealismo" },

  // Categoria: Cucina
  { category: "cucina", question: "Qual è il piatto tradizionale di Napoli?", options: ["Pizza Margherita", "Carbonara", "Lasagne", "Risotto"], answer: "Pizza Margherita" },
  { category: "cucina", question: "Quale formaggio si usa nella ricetta originale della Carbonara?", options: ["Pecorino Romano", "Parmigiano", "Grana Padano", "Mozzarella"], answer: "Pecorino Romano" },
  { category: "cucina", question: "Da quale regione proviene il pesto?", options: ["Liguria", "Toscana", "Lombardia", "Veneto"], answer: "Liguria" },
  { category: "cucina", question: "Qual è il dolce tipico siciliano a base di ricotta?", options: ["Cannolo", "Tiramisù", "Pastiera", "Babà"], answer: "Cannolo" },
  { category: "cucina", question: "Qual è il principale ingrediente del risotto alla milanese?", options: ["Zafferano", "Pomodoro", "Basilico", "Peperoncino"], answer: "Zafferano" }
];
